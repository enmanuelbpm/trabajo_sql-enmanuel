-- creo la base de datos
CREATE DATABASE IF NOT EXISTS TechSolutions;
-- uso la base de datos
USE TechSolutions;
-- creo la tabla independiente departamentos
CREATE TABLE IF NOT EXISTS Departamentos(
	ID_departamento INT UNIQUE NOT NULL PRIMARY KEY,
    Nombre_departamento VARCHAR(30) UNIQUE NOT NUll,
    Telefono_departamento INT NOT NULL,
	Ubicacion_departamento VARCHAR(50) NOT NULL
);
-- creo la tabla independiente cargos
CREATE TABLE IF NOT EXISTS Cargo(
ID_cargo int UNIQUE NOT NULL PRIMARY KEY,
Nombre_cargo VARCHAR(40) NOT NULL,
Sueldo_cargo DECIMAL(10,2) NOT NULL,
Nivel_cargo VARCHAR(30) NOT NULL 
);
-- creo la tabla independiente empleados
CREATE TABLE IF NOT EXISTS Empleados(
Cedula_empleado VARCHAR(20) NOT NULL PRIMARY KEY,
Nombre_empleado VARCHAR(30) NOT NULL,
Apellido_empleado VARCHAR(30) NOT NULL,
Telefono_empleado INT NOT NULL,
Correo_empleado VARCHAR(50) NOT NULL,
Genero_empleado VARCHAR(20) NOT NULL,
Fecha_inicio DATE NOT NULL,
Fecha_retiro DATE NOT NULL,
ID_departamento INT,
ID_cargo INT,
CONSTRAINT fk_empleado_departamento FOREIGN KEY (ID_departamento) REFERENCES Departamentos (ID_departamento),
CONSTRAINT fk_empleado_cargo FOREIGN KEY (ID_cargo) REFERENCES Cargos (ID_cargo)
);
-- creo la tabla independiente proyectos 
CREATE TABLE IF NOT EXISTS Proyectos(
ID_proyecto INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_proyecto VARCHAR(40) NOT NULL,
Fecha_inicio_proyecto DATE NOT NULL,
Fecha_entrega_proyecto DATE NOT NULL,
Estado_proyecto VARCHAR(30) NOT NULL
);
-- creo la tabla independiente empleado-proyectos
CREATE TABLE IF NOT EXISTS Empleado_proyectos(
ID_empleado_proyecto INT UNIQUE NOT NULL PRIMARY KEY,
Cedula_empleado VARCHAR(20),
ID_proyecto INT,
horas_asignadas INT NULL,
CONSTRAINT fk_empleado_proyecto_empleado FOREIGN KEY (Cedula_empleado) REFERENCES Empleados (Cedula_empleado),
CONSTRAINT fk_empleado_proyecto_proyecto FOREIGN KEY (ID_proyecto) REFERENCES Proyectos (ID_proyecto)
);
-- Con alter table modifique el tipo de variable de Telefono_departamento
ALTER TABLE Departamentos
MODIFY Telefono_departamento VARCHAR(20);
-- Con alter table modifique el tipo de variable de Telefono_empleado
ALTER TABLE Empleados
MODIFY Telefono_empleado VARCHAR(20);
-- Con alter table modifique de not null a null de Fecha_retiro
ALTER TABLE Empleados
MODIFY Fecha_retiro DATE NULL;