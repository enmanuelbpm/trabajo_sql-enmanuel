-- Consulte la tabla departamentos con SELECT*FROM
SELECT*FROM Departamentos;
-- Consulte la tabla cargos con SELECT*FROM
SELECT*FROM Cargos;
-- Consulte la tabla empleados con SELECT*FROM
SELECT*FROM Empleados;
-- Consulte la tabla proyectos con SELECT*FROM
SELECT*FROM Proyectos;
-- Consulte la tabla empleado_proyectos con SELECT*FROM
SELECT*FROM Empleado_proyectos;
-- Busque los nombres y correos de los empleados 
SELECT Nombre_empleado, Correo_empleado FROM Empleados;
-- Busque los empleados que trabajan en el departamento con ID=1
SELECT*FROM Empleados WHERE ID_departamento=1;
-- Bsuque los empleados que pertenezcan al departamento con ID=4 y que su genero sea femenino
SELECT*FROM Empleados WHERE ID_departamento=4 AND Genero_empleado='Femenino';
-- Busque los empleados que su apellido empiece con M
SELECT*FROM Empleados WHERE Apellido_empleado LIKE 'M%';
-- Busque los empleados que iniciaron trabajando en la empresa desde el 2020 al 2022
SELECT*FROM Empleados WHERE Fecha_inicio BETWEEN '2020-01-01'AND'2022-12-31';
-- Busque los cargos con sueldos mayores a 400000
SELECT*FROM Cargos WHERE Sueldo_cargo>400000;
-- Busque los empleados que su nombre tenga una A en el intermendio y que sea perteneciente al departamento con el ID=10
SELECT*FROM Empleados WHERE Nombre_empleado LIKE '%A%'AND ID_departamento=10;


